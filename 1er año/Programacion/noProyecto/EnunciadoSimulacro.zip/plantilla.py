# tu codigo va aqui

if __name__ == '__main__':
    print(Fibonacci.termino(10))
    print(Fibonacci.termino(1))
    print(Fibonacci.termino(-1))
    print(Fibonacci.termino('hola'))

#include "Evento.h"

Evento::Evento(){
   
}

Evento::Evento(const Fecha& f, const string& t,const string&d, int cat): fecha(f){
   
}

Evento::Evento(const Evento& e){

}

Evento& Evento::operator=(const Evento &e){

}

Evento::~Evento(){
}

//Operador de comparación
bool Evento::operator==(const Evento &e) const{
}

//Operador de comparación
bool Evento::operator!=(const Evento &e) const{
}

//Devuelve (una copia de) la fecha
Fecha Evento::getFecha() const{

}
//Devuelve (una copia de) la descripción
string Evento::getTitulo() const{

}
//Devuelve (una copia de) la descripción
string Evento::getDescripcion() const{

}
int Evento::getCategoria() const{

}

//Modifica la fecha
void Evento::setFecha(const Fecha& f){

}
//Modifica la descripción
void Evento::setTitulo(const string &t){

}

void Evento::setDescripcion(const string & d){

}

void Evento::setCategoria(int cat){

}

//Convierte en cadena
string Evento::aCadena(const vector<string>& categorias) const{

}

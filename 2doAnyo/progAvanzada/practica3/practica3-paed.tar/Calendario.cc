#include "Calendario.h"
/*** Calendario ***/

//Constructor por defecto: calendario sin ningún evento
Calendario::Calendario(){
    
}
//Constructor de copia
Calendario::Calendario(const Calendario& c){
    
}
//Operador de asignación
Calendario& Calendario::operator=(const Calendario &c){
   
}
//Destructor
Calendario::~Calendario(){

}

//Añade un evento al calendario. Si ya existía un evento en esa fecha, 
//devuelve false y no hace nada. En caso contrario, devuelve true.
bool Calendario::insertarEvento(const Evento& e){
   
}

//Elimina un evento del calendario. Si no había ningún evento asociado a esa fecha, 
//devuelve false y no hace nada. En caso contrario, devuelve true.
bool Calendario::eliminarEvento(const Fecha& f){
   
}

//Comprueba si hay algún evento asociado a la fecha dada
bool Calendario::comprobarEvento(const Fecha &f) const{
   
}


Evento Calendario::obtenerEvento(const Fecha& f) const{
   
}

//Devuelve una cadena con el contenido completo del calendario
string Calendario::aCadena(const vector<string>& categorias) const{
   
}

void Calendario::deshacerInsercion(){
   
}

void Calendario::deshacerBorrado(){
   
}
//Devuelve una cadena con el contenido completo del calendario
string Calendario::aCadenaPorTitulo(const string& t,const vector<string>& categorias) const{

}

int Calendario::categoriaMasFrecuente() const{

}

int Calendario::diaMasFrecuente() const{
}

int Calendario::mesMasFrecuente() const{
}

int Calendario::anyoMasFrecuente() const{
}

#include<string>
#include "Fecha.h"

using namespace std;


/* 
Métodos privados
Si decides implementar los métodos privados que se proponen en el fichero Fecha.h, 
puedes hacerlo aquí.

Asegúrate de añadir el código correspondiente en el interior de cada método
*/

/*
bool Fecha::esFechaCorrecta(int dia,int mes,int anyo) const{
}
*/

/*
bool Fecha::esBisiesto(int anyo) const{
}
*/

/*
int Fecha::calculaDiasMes(int mes, int anyo) const{
}
*/

/*
int Fecha::obtenerDiaSemana() const{
}
*/


/*
Métodos públicos
*/
Fecha::Fecha(){
    //Por favor, complétame
}

Fecha::Fecha(int d,int m,int a){
    //Por favor, complétame
}

Fecha::Fecha(const Fecha &f){
    //Por favor, complétame
}

Fecha::~Fecha(){
    //Por favor, complétame
}

Fecha& Fecha::operator=(const Fecha &f){
    //Por favor, complétame
    return *this;
}

int Fecha::getDia() const{
    //Por favor, complétame
    
    /* 
    La siguiente línea está incluida únicamente para facilitar la compilación de este código de ejemplo.
    Asegúrate de cambiarla
    */
    return 0;
}

int Fecha::getMes() const{
    //Por favor, complétame
    
    /* 
    La siguiente línea está incluida únicamente para facilitar la compilación de este código de ejemplo.
    Asegúrate de cambiarla
    */
    return 0;
}

int Fecha::getAnyo() const{
    //Por favor, complétame
    
    /* 
    La siguiente línea está incluida únicamente para facilitar la compilación de este código de ejemplo.
    Asegúrate de cambiarla
    */
    return 0;
}


bool Fecha::setDia(int d){
    //Por favor, complétame
    
    /* 
    La siguiente línea está incluida únicamente para facilitar la compilación de este código de ejemplo.
    Asegúrate de cambiarla
    */
   return false;
}

bool Fecha::setMes(int m){
    //Por favor, complétame
    
    /* 
    La siguiente línea está incluida únicamente para facilitar la compilación de este código de ejemplo.
    Asegúrate de cambiarla
    */
    return false;
}

bool Fecha::setAnyo(int a){
   //Por favor, complétame
    
    /* 
    La siguiente línea está incluida únicamente para facilitar la compilación de este código de ejemplo.
    Asegúrate de cambiarla
    */
    return false;
}


bool Fecha::operator==(const Fecha &f) const{
    //Por favor, complétame
    
    /* 
    La siguiente línea está incluida únicamente para facilitar la compilación de este código de ejemplo.
    Asegúrate de cambiarla
    */
    return false;
}

bool Fecha::operator!=(const Fecha &f) const{
    //Por favor, complétame
    
    /* 
    La siguiente línea está incluida únicamente para facilitar la compilación de este código de ejemplo.
    Asegúrate de cambiarla
    */
    return false;
}


bool Fecha::incrementaDias(int inc){
    //Por favor, complétame
    
    /* 
    La siguiente línea está incluida únicamente para facilitar la compilación de este código de ejemplo.
    Asegúrate de cambiarla
    */
    return false;
}

bool Fecha::incrementaMeses(int inc){
    //Por favor, complétame
    
    /* 
    La siguiente línea está incluida únicamente para facilitar la compilación de este código de ejemplo.
    Asegúrate de cambiarla
    */
    return false;
}

bool Fecha::incrementaAnyos(int inc){   
  //Por favor, complétame
    
    /* 
    La siguiente línea está incluida únicamente para facilitar la compilación de este código de ejemplo.
    Asegúrate de cambiarla
    */
    return false;
}


string Fecha::aCadena(bool larga, bool conDia) const{
   //Por favor, complétame
    
    /* 
    La siguiente línea está incluida únicamente para facilitar la compilación de este código de ejemplo.
    Asegúrate de cambiarla
    */
    return "";
}


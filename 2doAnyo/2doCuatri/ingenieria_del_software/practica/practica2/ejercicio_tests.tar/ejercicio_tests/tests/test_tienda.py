import unittest

from src.tienda import calcular_total

class TestTienda(unittest.TestCase):
    pass

#include "Evento.h"

Evento::Evento(){

}

Evento::Evento(const Fecha& f, const string& d){
}

Evento::Evento(const Evento& e){

}

Evento& Evento::operator=(const Evento &e){
}

Evento::~Evento(){

}

//Operador de comparación
bool Evento::operator==(const Evento &e) const{
}

//Operador de comparación
bool Evento::operator!=(const Evento &e) const{
}
//Operador de comparación
bool Evento::operator<(const Evento &e) const{
}

//Operador de comparación
bool Evento::operator>(const Evento &e) const{
}

//Devuelve (una copia de) la fecha
Fecha Evento::getFecha() const{
}

//Devuelve (una copia de) la descripción
string Evento::getDescripcion() const{
}

//Modifica la fecha
void Evento::setFecha(const Fecha& f){
}

//Modifica la descripción
bool Evento::setDescripcion(const string &d){     
}
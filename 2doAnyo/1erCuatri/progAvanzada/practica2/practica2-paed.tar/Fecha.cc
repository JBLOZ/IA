#include<string>
#include "Fecha.h"

using namespace std;


//Método auxiliares: eliminar si no se han implementado
bool Fecha::esFechaCorrecta(int dia,int mes,int anyo) const{}
bool Fecha::esBisiesto(int a) const{}
int Fecha::calculaDiasMes(int m, int a) const{}
int Fecha::obtenerDiaSemana() const{}


Fecha::Fecha(){

}

Fecha::Fecha(int d,int m,int a){

}

Fecha::Fecha(const Fecha &f){

}

Fecha::~Fecha(){

}

Fecha& Fecha::operator=(const Fecha &f){

    
}

int Fecha::getDia() const{

}

int Fecha::getMes() const{

}

int Fecha::getAnyo() const{
    
}

bool Fecha::setDia(int d){
    
}

bool Fecha::setMes(int m){
    
}

bool Fecha::setAnyo(int a){
    
}

bool Fecha::operator==(const Fecha &f) const{
    
}

bool Fecha::operator!=(const Fecha &f) const{
    
}

bool Fecha::operator<(const Fecha &f) const{
    
}

bool Fecha::operator>(const Fecha &f) const{
}


bool Fecha::incrementaDias(int inc){
}

bool Fecha::incrementaMeses(int inc){
}

bool Fecha::incrementaAnyos(int inc){
}

string Fecha::aCadena(bool larga, bool conDia) const{
}

 

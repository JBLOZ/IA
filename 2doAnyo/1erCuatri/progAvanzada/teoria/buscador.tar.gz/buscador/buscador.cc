#include<iostream>
#include<fstream>
#include<string>
#include<vector>
#include<unordered_map>
#include<set>
using namespace std;

int main(){
    vector<string> documentos;

    //Abrir fichero index.txt y leer línea a línea
    ifstream f;
    f.open("BD/index.txt");
    if(f.is_open()){
        string s;
        while(getline(f,s)){
            documentos.push_back(s);
        }
        f.close();
    }

    //Imprimir documentos
    cout << "El buscador contiene los siguientes documentos:" << endl;
    for(int i=0; i < documentos.size(); i++)
        cout << i << ": " << documentos[i] << endl;
    
    //Indexar: el índice asocia a cada palabra (clave) un conjunto de documentos en los que aparece (valor)
    unordered_map<string,set<int>> indice;
    for(int i=0; i < documentos.size(); i++){
        string doc_name=documentos[i];

        //abrir el documento número i y actualizar el índice
        ifstream f;
        f.open("BD/"+doc_name);
        if(f.is_open()){
            string word;
            f >> word;
            while(! f.eof()){
                indice[word].insert(i);

                f>> word;
            }

            f.close();
        }
    }

    //Buscar
    string busqueda;
    cout << "Introduce una palabra (déjala en blanco para salir):";
    getline(cin,busqueda);
    while(busqueda != ""){
        cout << "La palabra '"<< busqueda << "' se encuentra en los siguientes documentos:" << endl;
        if( indice.count(busqueda) > 0 ){
            for(auto it=indice.at(busqueda).begin(); it != indice.at(busqueda).end(); ++it){
                cout << documentos[*it] << endl;   
            }
        }

        cout << endl;
        cout << "Introduce una palabra (déjala en blanco para salir):";
        getline(cin,busqueda);
    }
        
    

    return 0;
}